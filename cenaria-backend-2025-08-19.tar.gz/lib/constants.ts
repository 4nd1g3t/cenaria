// lib/constants.ts
export const MAX_PANTRY_ITEMS = 50;
